readme.txt

The Terms of Use (https://www.gisaid.org/DAA) you agreed to when requesting access credentials to GISAID include the following:

1) You will not distribute, redistribute, share, or otherwise make available Data, to any third party or the public, unless the individual is an Authorized User of GISAID;
2) You will not display Data, in whole or in part, on any website, media material, or as part of a service, without GISAID’s express written permission;
3) You will treat all Data contained in these files consistent with other Data in GISAID and in accordance with the GISAID Database Access Agreement (“DAA”);
4) You will provide proper attributions and acknowledgements (see Citation and Acknowledgement Guide (https://gisaid.org/publish/)), and make best efforts to collaborate consistent with the DAA when using Data in any publication, including preprints, manuscripts, articles, and any other analyses.

By downloading these files, you are reaffirming your agreement to the GISAID Terms of Use and the Database Access Agreement.

